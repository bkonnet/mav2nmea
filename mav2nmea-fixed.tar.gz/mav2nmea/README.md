# mav2nmea (con fixes)

Puente **MAVLink → NMEA** ligero para USV/ROV (con fixes de sockets).

- **Entrada**: MAVLink por UDP (desde BlueOS o Pixhawk)
- **Salida**: NMEA (RMC/GGA/VTG/HDT) por **TCP** (server) y **UDP** (targets configurables)

## Instalación rápida

```bash
chmod +x install.sh
sudo ./install.sh
sudo systemctl status mav2nmea
```

## Variables de entorno (opcional)

Edita el servicio:
```bash
sudo systemctl edit mav2nmea
```
y agrega, por ejemplo:
```
[Service]
Environment=MAVLINK_UDP_PORT=14560
Environment=NMEA_TCP_PORT=10111
Environment=NMEA_UDP_TARGETS=192.168.1.255:10110,10.0.0.5:10110
```
Luego:
```bash
sudo systemctl daemon-reload
sudo systemctl restart mav2nmea
```

## Uso

- TCP NMEA server: `:10110` (por defecto, configurable con `NMEA_TCP_PORT`)
- UDP NMEA targets: `NMEA_UDP_TARGETS`
- Entrada MAVLink UDP: `:14552` (o el que definas en `MAVLINK_UDP_PORT`)
